package com.ledgix.accounting

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.webkit.ConsoleMessage
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private lateinit var webView: WebView
    private val FILE_CHOOSER_REQUEST = 4107

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                this@MainActivity.fileChooserCallback = filePathCallback
                // PDF bhi chun sake: accept types HTML se aate hain, warna image + PDF dono
                val accept = fileChooserParams?.acceptTypes?.filter { it.isNotBlank() }?.toTypedArray()
                val mimes: Array<String> = if (accept != null && accept.isNotEmpty()) accept else arrayOf("image/*", "application/pdf")
                return try {
                    val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        putExtra(Intent.EXTRA_MIME_TYPES, mimes)
                    }
                    val chooser = Intent.createChooser(intent, this@MainActivity.getString(R.string.app_full_name) + " — File Chunein")
                    try {
                        startActivityForResult(chooser, FILE_CHOOSER_REQUEST)
                    } catch (ex: Exception) {
                        val fallback = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "*/*"
                            putExtra(Intent.EXTRA_MIME_TYPES, mimes)
                        }
                        startActivityForResult(Intent.createChooser(fallback, this@MainActivity.getString(R.string.app_full_name) + " — File Chunein"), FILE_CHOOSER_REQUEST)
                    }
                    true
                } catch (e: Exception) {
                    this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                    this@MainActivity.fileChooserCallback = null
                    Toast.makeText(this@MainActivity, "File chooser nahi khul paaya. Files app se try karein.", Toast.LENGTH_LONG).show()
                    Log.e("LEDGIX", "Logo picker launch failed", e)
                    false
                }
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                Toast.makeText(this@MainActivity, message ?: this@MainActivity.getString(R.string.app_name), Toast.LENGTH_LONG).show()
                result.confirm()
                return true
            }

            override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                Log.e("LEDGIXJS", "${consoleMessage.message()} (line ${consoleMessage.lineNumber()})")
                return true
            }
        }
        webView.addJavascriptInterface(Bridge(this, webView), "AndroidBridge")
        webView.loadUrl("file:///android_asset/ledgix.html")
        setContentView(webView)
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_CHOOSER_REQUEST) {
            val result: Array<Uri>? = if (resultCode == Activity.RESULT_OK) {
                val clip = data?.clipData
                when {
                    clip != null && clip.itemCount > 0 -> Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                    data?.data != null -> arrayOf(data.data!!)
                    else -> null
                }
            } else null
            fileChooserCallback?.onReceiveValue(result)
            fileChooserCallback = null
        }
    }

    override fun onDestroy() {
        fileChooserCallback?.onReceiveValue(null)
        fileChooserCallback = null
        super.onDestroy()
    }
}
