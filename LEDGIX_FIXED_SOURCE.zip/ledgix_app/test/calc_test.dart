import 'package:flutter_test/flutter_test.dart';
import 'package:ledgix/utils/calc.dart';

Map<String, dynamic> line({double qty = 1, int rate = 10000, int taxRate = 1800}) => {
      'item_id': 'x',
      'item_name': 'Test item',
      'quantity': qty,
      'rate': rate,
      'tax_rate': taxRate,
    };

void main() {
  test('intra-state sale splits tax into CGST and SGST', () {
    final t = calculateInvoice(
      items: [line(qty: 2, rate: 10000)], // Rs. 200 taxable at 18%
      sellerState: '08',
      placeOfSupply: '08',
    );
    expect(t.subtotal, 20000);
    expect(t.cgst, 1800);
    expect(t.sgst, 1800);
    expect(t.igst, 0);
    expect(t.total, 23600);
    expect(t.roundOff, 0);
  });

  test('inter-state sale uses IGST only', () {
    final t = calculateInvoice(
      items: [line(qty: 2, rate: 10000)],
      sellerState: '08',
      placeOfSupply: '27',
    );
    expect(t.cgst, 0);
    expect(t.sgst, 0);
    expect(t.igst, 3600);
    expect(t.total, 23600);
  });

  test('total is rounded to nearest rupee and round off is reported', () {
    // Rs. 101 taxable at 18% = Rs. 18.18 tax -> before rounding 11918 paise.
    final t = calculateInvoice(
      items: [line(qty: 1, rate: 10100)],
      sellerState: '08',
      placeOfSupply: '08',
    );
    expect(t.subtotal, 10100);
    expect(t.total, 11900);
    expect(t.roundOff, -18);
  });

  test('zero rate item adds no tax', () {
    final t = calculateInvoice(
      items: [line(taxRate: 0)],
      sellerState: '08',
      placeOfSupply: '08',
    );
    expect(t.cgst + t.sgst + t.igst, 0);
    expect(t.total, 10000);
  });

  test('quantity with decimals is handled', () {
    final t = calculateInvoice(
      items: [line(qty: 1.5, rate: 10000, taxRate: 500)], // 5%
      sellerState: '08',
      placeOfSupply: '08',
    );
    expect(t.subtotal, 15000);
    expect(t.cgst + t.sgst, 750);
  });
}
