import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const LedgixApp());
}

class LedgixApp extends StatelessWidget {
  const LedgixApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ledgix',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF1E6B52),
        useMaterial3: true,
        inputDecorationTheme: const InputDecorationTheme(isDense: false),
      ),
      home: const HomeScreen(),
    );
  }
}
