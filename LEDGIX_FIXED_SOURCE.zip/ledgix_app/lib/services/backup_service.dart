import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../db/repo.dart';

/// Writes all data to a JSON file and opens the share sheet
/// (save to Drive, email, or WhatsApp to yourself).
Future<void> exportBackup() async {
  final data = await Repo.exportAll();
  final dir = await getTemporaryDirectory();
  final stamp = DateTime.now().millisecondsSinceEpoch;
  final file = File('${dir.path}/ledgix_backup_$stamp.json');
  await file.writeAsString(const JsonEncoder.withIndent('  ').convert(data));
  await Share.shareXFiles([XFile(file.path)], subject: 'Ledgix backup');
}
