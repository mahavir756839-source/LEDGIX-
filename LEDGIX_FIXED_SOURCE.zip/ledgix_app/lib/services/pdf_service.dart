import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../db/row.dart';
import '../utils/format.dart';

/// Builds an A4 invoice PDF and opens the system share sheet.
/// Uses the default PDF font (ASCII only), so amounts are written as "Rs.".
Future<void> shareInvoicePdf({
  required Row business,
  required Row invoice,
  required List<Row> lines,
  required String partyName,
}) async {
  final doc = pw.Document();
  final type = typeLabel(invoice['invoice_type'] as String).toUpperCase();
  final cgst = invoice['cgst'] as int;
  final sgst = invoice['sgst'] as int;
  final igst = invoice['igst'] as int;
  final gstin = (business['gstin'] ?? '').toString();
  final address = (business['address'] ?? '').toString();
  final phone = (business['phone'] ?? '').toString();

  final headerStyle = pw.TextStyle(fontWeight: pw.FontWeight.bold);

  doc.addPage(
    pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(32),
      build: (context) => [
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text((business['business_name'] ?? 'My Business').toString(),
                    style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
                if (address.isNotEmpty) pw.Text(address),
                if (phone.isNotEmpty) pw.Text('Phone: $phone'),
                if (gstin.isNotEmpty) pw.Text('GSTIN: $gstin'),
              ],
            ),
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.end,
              children: [
                pw.Text(type, style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
                pw.Text('No: ${invoice['invoice_number']}'),
                pw.Text('Date: ${fmtDate(invoice['invoice_date'] as int)}'),
              ],
            ),
          ],
        ),
        pw.SizedBox(height: 20),
        pw.Text('Party: $partyName', style: headerStyle),
        pw.SizedBox(height: 12),
        pw.TableHelper.fromTextArray(
          headers: ['#', 'Item', 'HSN', 'Qty', 'Rate', 'GST %', 'Amount'],
          data: [
            for (var i = 0; i < lines.length; i++)
              [
                '${i + 1}',
                lines[i]['item_name'],
                lines[i]['hsn_code'] ?? '',
                '${fmtQty(lines[i]['quantity'] as num)} ${lines[i]['unit'] ?? ''}',
                plain(lines[i]['rate'] as int),
                gstLabel(lines[i]['tax_rate'] as int),
                plain(lines[i]['line_total'] as int),
              ],
          ],
          cellAlignment: pw.Alignment.centerLeft,
          headerStyle: headerStyle,
          cellPadding: const pw.EdgeInsets.all(5),
        ),
        pw.SizedBox(height: 16),
        pw.Align(
          alignment: pw.Alignment.centerRight,
          child: pw.Container(
            width: 240,
            child: pw.Column(
              children: [
                _kv('Subtotal', rs(invoice['subtotal'] as int)),
                if (cgst > 0) _kv('CGST', rs(cgst)),
                if (sgst > 0) _kv('SGST', rs(sgst)),
                if (igst > 0) _kv('IGST', rs(igst)),
                _kv('Round off', plain(invoice['round_off'] as int)),
                pw.Divider(),
                _kv('Total', rs(invoice['total'] as int), bold: true),
              ],
            ),
          ),
        ),
        if ((invoice['notes'] ?? '').toString().isNotEmpty) ...[
          pw.SizedBox(height: 20),
          pw.Text('Notes: ${invoice['notes']}'),
        ],
      ],
    ),
  );

  final bytes = await doc.save();
  await Printing.sharePdf(bytes: bytes, filename: '${invoice['invoice_number']}.pdf');
}

pw.Widget _kv(String label, String value, {bool bold = false}) {
  final style = pw.TextStyle(fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal);
  return pw.Padding(
    padding: const pw.EdgeInsets.symmetric(vertical: 2),
    child: pw.Row(
      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
      children: [pw.Text(label, style: style), pw.Text(value, style: style)],
    ),
  );
}
