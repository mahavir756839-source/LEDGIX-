import 'package:flutter/material.dart';

import '../db/repo.dart';
import '../services/backup_service.dart';
import '../widgets/common.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _gstin = TextEditingController();
  final _state = TextEditingController();
  final _address = TextEditingController();
  final _phone = TextEditingController();
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final b = await Repo.business();
    _name.text = (b['business_name'] ?? '').toString();
    _gstin.text = (b['gstin'] ?? '').toString();
    _state.text = (b['state_code'] ?? '').toString();
    _address.text = (b['address'] ?? '').toString();
    _phone.text = (b['phone'] ?? '').toString();
    if (mounted) setState(() => _loading = false);
  }

  @override
  void dispose() {
    for (final c in [_name, _gstin, _state, _address, _phone]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    await Repo.saveBusiness({
      'business_name': _name.text.trim(),
      'gstin': _gstin.text.trim().toUpperCase(),
      'state_code': _state.text.trim(),
      'address': _address.text.trim(),
      'phone': _phone.text.trim(),
    });
    if (mounted) {
      snack(context, 'Business details saved');
      Navigator.pop(context);
    }
  }

  Future<void> _backup() async {
    try {
      await exportBackup();
    } catch (e) {
      if (mounted) snack(context, 'Backup failed: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  sectionTitle('Business profile'),
                  textField(_name, 'Business name', required: true),
                  textField(_gstin, 'GSTIN', hint: '15 characters, optional'),
                  textField(_state, 'State code', keyboard: TextInputType.number,
                      hint: 'e.g. 08 for Rajasthan. Used for CGST/SGST vs IGST'),
                  textField(_address, 'Address', maxLines: 2),
                  textField(_phone, 'Phone', keyboard: TextInputType.phone),
                  FilledButton(onPressed: _save, child: const Text('Save')),
                  sectionTitle('Data'),
                  OutlinedButton.icon(
                    icon: const Icon(Icons.backup),
                    label: const Text('Export backup (JSON)'),
                    onPressed: _backup,
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Your data is stored on this phone. Keep a backup file in a safe place.',
                    style: TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ),
    );
  }
}
