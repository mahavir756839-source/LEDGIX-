import 'package:flutter/material.dart';

import '../db/repo.dart';
import '../db/row.dart';
import '../utils/format.dart';
import '../widgets/common.dart';

class ItemsScreen extends StatefulWidget {
  const ItemsScreen({super.key});

  @override
  State<ItemsScreen> createState() => _ItemsScreenState();
}

class _ItemsScreenState extends State<ItemsScreen> {
  List<Row> _items = [];
  Map<String, double> _stock = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final items = await Repo.items();
    final stock = await Repo.stocks();
    if (!mounted) return;
    setState(() {
      _items = items;
      _stock = stock;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_items.isEmpty) return emptyState('No items yet. Tap "New item" to add a product or service.');

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.separated(
        itemCount: _items.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (_, i) {
          final it = _items[i];
          final isService = it['item_type'] == 'service';
          final stock = _stock[it['id'] as String] ?? 0;
          final minStock = (it['min_stock'] as num).toDouble();
          final low = !isService && it['track_stock'] == 1 && minStock > 0 && stock <= minStock;
          return ListTile(
            title: Text(it['name'] as String),
            subtitle: Text(
              'HSN ${(it['hsn_code'] as String? ?? '-')} • GST ${gstLabel(it['tax_rate'] as int)}'
              '${isService ? '' : ' • Stock: ${fmtQty(stock)} ${it['unit']}'}',
              style: TextStyle(color: low ? Colors.red : null),
            ),
            trailing: Text(rs(it['sale_price'] as int)),
            onTap: () async {
              await Navigator.push(
                  context, MaterialPageRoute(builder: (_) => ItemFormScreen(item: it)));
              _load();
            },
          );
        },
      ),
    );
  }
}

class ItemFormScreen extends StatefulWidget {
  final Row? item;
  const ItemFormScreen({super.key, this.item});

  @override
  State<ItemFormScreen> createState() => _ItemFormScreenState();
}

class _ItemFormScreenState extends State<ItemFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _code;
  late final TextEditingController _hsn;
  late final TextEditingController _salePrice;
  late final TextEditingController _purchasePrice;
  late final TextEditingController _openingStock;
  late final TextEditingController _minStock;
  late String _type;
  late String _unit;
  late int _taxRate;
  late bool _trackStock;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final it = widget.item ?? {};
    _name = TextEditingController(text: it['name'] ?? '');
    _code = TextEditingController(text: it['item_code'] ?? '');
    _hsn = TextEditingController(text: it['hsn_code'] ?? '');
    _salePrice = TextEditingController(text: _rupees(it['sale_price']));
    _purchasePrice = TextEditingController(text: _rupees(it['purchase_price']));
    _openingStock = TextEditingController(text: '${it['opening_stock'] ?? 0}');
    _minStock = TextEditingController(text: '${it['min_stock'] ?? 0}');
    _type = it['item_type'] ?? 'product';
    _unit = it['unit'] ?? 'PCS';
    _taxRate = it['tax_rate'] ?? 1800;
    _trackStock = (it['track_stock'] ?? 1) == 1;
  }

  String _rupees(Object? paise) =>
      paise == null ? '' : ((paise as int) / 100).toStringAsFixed(2);

  @override
  void dispose() {
    for (final c in [_name, _code, _hsn, _salePrice, _purchasePrice, _openingStock, _minStock]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    final isService = _type == 'service';
    final row = <String, dynamic>{
      if (widget.item != null) 'id': widget.item!['id'],
      'name': _name.text.trim(),
      'item_code': _code.text.trim(),
      'item_type': _type,
      'hsn_code': _hsn.text.trim(),
      'unit': isService ? 'SERVICE' : _unit,
      'sale_price': toPaise(_salePrice.text),
      'purchase_price': toPaise(_purchasePrice.text),
      'tax_rate': _taxRate,
      'track_stock': (!isService && _trackStock) ? 1 : 0,
      'opening_stock': double.tryParse(_openingStock.text.trim()) ?? 0,
      'min_stock': double.tryParse(_minStock.text.trim()) ?? 0,
    };
    await Repo.saveItem(row);
    if (mounted) Navigator.pop(context);
  }

  Future<void> _delete() async {
    final ok = await confirm(context, 'Delete item?', 'Past invoices keep their item details.');
    if (!ok) return;
    await Repo.deleteItem(widget.item!['id'] as String);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final isService = _type == 'service';
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.item == null ? 'New item' : 'Edit item'),
        actions: [
          if (widget.item != null)
            IconButton(icon: const Icon(Icons.delete_outline), onPressed: _delete),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            textField(_name, 'Item name', required: true),
            DropdownButtonFormField<String>(
              value: _type,
              decoration: const InputDecoration(labelText: 'Type', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 'product', child: Text('Product')),
                DropdownMenuItem(value: 'service', child: Text('Service')),
              ],
              onChanged: (v) => setState(() => _type = v ?? 'product'),
            ),
            const SizedBox(height: 12),
            textField(_code, 'Item code / SKU'),
            textField(_hsn, 'HSN / SAC code', keyboard: TextInputType.number),
            if (!isService)
              DropdownButtonFormField<String>(
                value: _unit,
                decoration: const InputDecoration(labelText: 'Unit', border: OutlineInputBorder()),
                items: [for (final u in kUnits) DropdownMenuItem(value: u, child: Text(u))],
                onChanged: (v) => setState(() => _unit = v ?? 'PCS'),
              ),
            const SizedBox(height: 12),
            DropdownButtonFormField<int>(
              value: _taxRate,
              decoration: const InputDecoration(labelText: 'GST rate', border: OutlineInputBorder()),
              items: [for (final r in kGstRates) DropdownMenuItem(value: r, child: Text(gstLabel(r)))],
              onChanged: (v) => setState(() => _taxRate = v ?? 1800),
            ),
            const SizedBox(height: 12),
            textField(_salePrice, 'Sale price (Rs.)',
                keyboard: const TextInputType.numberWithOptions(decimal: true), required: true),
            textField(_purchasePrice, 'Purchase price (Rs.)',
                keyboard: const TextInputType.numberWithOptions(decimal: true)),
            if (!isService) ...[
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Track stock'),
                value: _trackStock,
                onChanged: (v) => setState(() => _trackStock = v),
              ),
              if (_trackStock) ...[
                textField(_openingStock, 'Opening stock',
                    keyboard: const TextInputType.numberWithOptions(decimal: true)),
                textField(_minStock, 'Low stock alert at',
                    keyboard: const TextInputType.numberWithOptions(decimal: true)),
              ],
            ],
            const SizedBox(height: 8),
            FilledButton(
              onPressed: _saving ? null : _save,
              child: const Text('Save item'),
            ),
          ],
        ),
      ),
    );
  }
}
