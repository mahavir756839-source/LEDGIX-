import 'package:flutter/material.dart';

import '../db/repo.dart';
import '../db/row.dart';
import '../utils/format.dart';
import '../widgets/common.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  late DateTimeRange _range;
  List<Row> _summary = [];
  List<Row> _balances = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _range = DateTimeRange(
      start: DateTime(now.year, now.month, 1),
      end: DateTime(now.year, now.month + 1, 0),
    );
    _load();
  }

  Future<void> _load() async {
    final from = DateTime(_range.start.year, _range.start.month, _range.start.day);
    final to = DateTime(_range.end.year, _range.end.month, _range.end.day, 23, 59, 59, 999);
    final summary = await Repo.salesSummary(from.millisecondsSinceEpoch, to.millisecondsSinceEpoch);

    final parties = await Repo.parties();
    final balances = await Repo.partyBalances();
    final rows = <Row>[];
    for (final p in parties) {
      final bal = balances[p['id'] as String] ?? 0;
      if (bal != 0) rows.add({'name': p['name'], 'balance': bal});
    }
    rows.sort((a, b) => (b['balance'] as int).abs().compareTo((a['balance'] as int).abs()));

    if (!mounted) return;
    setState(() {
      _summary = summary;
      _balances = rows;
      _loading = false;
    });
  }

  Row _forType(String type) {
    for (final r in _summary) {
      if (r['invoice_type'] == type) return r;
    }
    return {'cnt': 0, 'subtotal': 0, 'cgst': 0, 'sgst': 0, 'igst': 0, 'total': 0};
  }

  Future<void> _pickRange() async {
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      initialDateRange: _range,
    );
    if (picked != null) {
      setState(() {
        _range = picked;
        _loading = true;
      });
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());

    final sale = _forType('sale');
    final purchase = _forType('purchase');

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          OutlinedButton.icon(
            icon: const Icon(Icons.date_range),
            label: Text('${fmtDate(_range.start.millisecondsSinceEpoch)}  to  '
                '${fmtDate(_range.end.millisecondsSinceEpoch)}'),
            onPressed: _pickRange,
          ),
          sectionTitle('Sales'),
          _typeCard(sale),
          sectionTitle('Purchases'),
          _typeCard(purchase),
          sectionTitle('GST summary (sales)'),
          _line('Taxable value', rs(sale['subtotal'] as int)),
          _line('CGST collected', rs(sale['cgst'] as int)),
          _line('SGST collected', rs(sale['sgst'] as int)),
          _line('IGST collected', rs(sale['igst'] as int)),
          _line('Total tax', rs((sale['cgst'] as int) + (sale['sgst'] as int) + (sale['igst'] as int))),
          sectionTitle('Outstanding balances (all time)'),
          if (_balances.isEmpty) const Text('No outstanding balances.'),
          for (final b in _balances)
            _line(
              '${b['name']}',
              b['balance'] as int > 0
                  ? 'Receive ${rs(b['balance'] as int)}'
                  : 'Pay ${rs((b['balance'] as int).abs())}',
            ),
        ],
      ),
    );
  }

  Widget _typeCard(Row r) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            _line('Invoices', '${r['cnt']}'),
            _line('Taxable value', rs(r['subtotal'] as int)),
            _line('Total (with tax)', rs(r['total'] as int), bold: true),
          ],
        ),
      ),
    );
  }

  Widget _line(String label, String value, {bool bold = false}) {
    final style = TextStyle(fontWeight: bold ? FontWeight.bold : null);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Flexible(child: Text(label, style: style)),
          Text(value, style: style),
        ],
      ),
    );
  }
}
