import 'package:flutter/material.dart';

import '../db/repo.dart';
import '../db/row.dart';
import '../services/pdf_service.dart';
import '../utils/calc.dart';
import '../utils/format.dart';
import '../widgets/common.dart';

// ---------------------------------------------------------------- list

class InvoicesScreen extends StatefulWidget {
  const InvoicesScreen({super.key});

  @override
  State<InvoicesScreen> createState() => _InvoicesScreenState();
}

class _InvoicesScreenState extends State<InvoicesScreen> {
  static const _filters = [
    ('All', null),
    ('Sale', 'sale'),
    ('Purchase', 'purchase'),
    ('Estimate', 'estimate'),
  ];

  String? _type;
  List<Row> _rows = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final rows = await Repo.invoices(type: _type);
    if (!mounted) return;
    setState(() {
      _rows = rows;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Wrap(
            spacing: 8,
            children: [
              for (final f in _filters)
                ChoiceChip(
                  label: Text(f.$1),
                  selected: _type == f.$2,
                  onSelected: (_) {
                    _type = f.$2;
                    _load();
                  },
                ),
            ],
          ),
        ),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : _rows.isEmpty
                  ? emptyState('No invoices yet. Tap "New invoice" to create one.')
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: ListView.separated(
                        itemCount: _rows.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (_, i) {
                          final inv = _rows[i];
                          return ListTile(
                            title: Text('${inv['invoice_number']}  •  ${inv['party_name'] ?? ''}'),
                            subtitle: Text(
                                '${fmtDate(inv['invoice_date'] as int)} • ${invoiceStatus(inv)}'),
                            trailing: Text(rs(inv['total'] as int),
                                style: const TextStyle(fontWeight: FontWeight.bold)),
                            onTap: () async {
                              await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) =>
                                          InvoiceDetailScreen(invoiceId: inv['id'] as String)));
                              _load();
                            },
                          );
                        },
                      ),
                    ),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------- new invoice

class _Line {
  String? itemId;
  final qty = TextEditingController(text: '1');
  final rate = TextEditingController();

  void dispose() {
    qty.dispose();
    rate.dispose();
  }
}

class InvoiceFormScreen extends StatefulWidget {
  const InvoiceFormScreen({super.key});

  @override
  State<InvoiceFormScreen> createState() => _InvoiceFormScreenState();
}

class _InvoiceFormScreenState extends State<InvoiceFormScreen> {
  final _notes = TextEditingController();
  final _received = TextEditingController();
  final _lines = <_Line>[];

  List<Row> _parties = [];
  List<Row> _items = [];
  String _sellerState = '';
  String _type = 'sale';
  String? _partyId;
  String _mode = 'cash';
  DateTime _date = DateTime.now();
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _lines.add(_Line());
    _init();
  }

  Future<void> _init() async {
    final parties = await Repo.parties();
    final items = await Repo.items();
    final sellerState = await Repo.setting('state_code') ?? '';
    if (!mounted) return;
    setState(() {
      _parties = parties;
      _items = items;
      _sellerState = sellerState;
      _loading = false;
    });
  }

  @override
  void dispose() {
    _notes.dispose();
    _received.dispose();
    for (final l in _lines) {
      l.dispose();
    }
    super.dispose();
  }

  Row? _findItem(String? id) {
    for (final it in _items) {
      if (it['id'] == id) return it;
    }
    return null;
  }

  Row? _findParty(String? id) {
    for (final p in _parties) {
      if (p['id'] == id) return p;
    }
    return null;
  }

  void _pickItem(_Line line, String? id) {
    final item = _findItem(id);
    setState(() {
      line.itemId = id;
      if (item != null) {
        final paise = _type == 'purchase' ? item['purchase_price'] : item['sale_price'];
        line.rate.text = ((paise as int) / 100).toStringAsFixed(2);
      }
    });
  }

  String _placeOfSupply() {
    final partyState = _findParty(_partyId)?['state_code'] as String? ?? '';
    return partyState.isNotEmpty ? partyState : _sellerState;
  }

  List<Row> _lineRows() {
    final out = <Row>[];
    for (final l in _lines) {
      final item = _findItem(l.itemId);
      final qty = double.tryParse(l.qty.text.trim()) ?? 0;
      if (item == null || qty <= 0) continue;
      out.add({
        'item_id': item['id'],
        'item_name': item['name'],
        'hsn_code': item['hsn_code'],
        'unit': item['unit'],
        'quantity': qty,
        'rate': toPaise(l.rate.text),
        'tax_rate': item['tax_rate'],
      });
    }
    return out;
  }

  Future<void> _save() async {
    if (_partyId == null) {
      snack(context, 'Select a party');
      return;
    }
    final rows = _lineRows();
    if (rows.isEmpty) {
      snack(context, 'Add at least one item with quantity');
      return;
    }
    setState(() => _saving = true);
    try {
      final number = await Repo.createInvoice(
        type: _type,
        partyId: _partyId!,
        date: _date.millisecondsSinceEpoch,
        placeOfSupply: _placeOfSupply(),
        lines: rows,
        notes: _notes.text.trim().isEmpty ? null : _notes.text.trim(),
        receivedNow: _type == 'estimate' ? 0 : toPaise(_received.text),
        mode: _mode,
      );
      if (!mounted) return;
      snack(context, 'Saved $number');
      Navigator.pop(context);
    } catch (e) {
      if (mounted) snack(context, 'Could not save: $e');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final preview = calculateInvoice(
      items: _lineRows(),
      sellerState: _sellerState,
      placeOfSupply: _placeOfSupply(),
    );
    final intra = _sellerState.isNotEmpty && _sellerState == _placeOfSupply();

    return Scaffold(
      appBar: AppBar(title: Text('New ${typeLabel(_type).toLowerCase()}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'sale', label: Text('Sale')),
              ButtonSegment(value: 'purchase', label: Text('Purchase')),
              ButtonSegment(value: 'estimate', label: Text('Estimate')),
            ],
            selected: {_type},
            onSelectionChanged: (s) => setState(() {
              _type = s.first;
              for (final l in _lines) {
                if (l.itemId != null) _pickItem(l, l.itemId);
              }
            }),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _partyId,
            decoration: InputDecoration(
              labelText: _type == 'purchase' ? 'Supplier' : 'Customer',
              border: const OutlineInputBorder(),
            ),
            items: [
              for (final p in _parties)
                DropdownMenuItem(value: p['id'] as String, child: Text(p['name'] as String)),
            ],
            onChanged: (v) => setState(() => _partyId = v),
            hint: _parties.isEmpty ? const Text('Add a party first') : null,
          ),
          const SizedBox(height: 12),
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text('Date: ${fmtDate(_date.millisecondsSinceEpoch)}'),
            trailing: const Icon(Icons.calendar_today),
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: _date,
                firstDate: DateTime(2020),
                lastDate: DateTime(2100),
              );
              if (picked != null) setState(() => _date = picked);
            },
          ),
          sectionTitle('Items'),
          if (_items.isEmpty)
            const Text('No items yet. Add items in the Items tab first.'),
          for (var i = 0; i < _lines.length; i++) _lineCard(i),
          OutlinedButton.icon(
            icon: const Icon(Icons.add),
            label: const Text('Add item'),
            onPressed: () => setState(() => _lines.add(_Line())),
          ),
          sectionTitle('Totals'),
          _totalRow('Subtotal', rs(preview.subtotal)),
          if (intra) _totalRow('CGST', rs(preview.cgst)),
          if (intra) _totalRow('SGST', rs(preview.sgst)),
          if (!intra && preview.igst > 0) _totalRow('IGST', rs(preview.igst)),
          _totalRow('Round off', plain(preview.roundOff)),
          _totalRow('Total', rs(preview.total), bold: true),
          const SizedBox(height: 12),
          if (_type != 'estimate') ...[
            textField(_received, 'Amount received now (Rs.) - optional',
                keyboard: const TextInputType.numberWithOptions(decimal: true)),
            DropdownButtonFormField<String>(
              value: _mode,
              decoration: const InputDecoration(labelText: 'Mode', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 'cash', child: Text('Cash')),
                DropdownMenuItem(value: 'bank', child: Text('Bank transfer')),
                DropdownMenuItem(value: 'upi', child: Text('UPI')),
                DropdownMenuItem(value: 'cheque', child: Text('Cheque')),
                DropdownMenuItem(value: 'card', child: Text('Card')),
              ],
              onChanged: (v) => setState(() => _mode = v ?? 'cash'),
            ),
            const SizedBox(height: 12),
          ],
          textField(_notes, 'Notes', maxLines: 2),
          const SizedBox(height: 8),
          FilledButton(
            onPressed: _saving ? null : _save,
            child: const Text('Save invoice'),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _lineCard(int i) {
    final line = _lines[i];
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Row(children: [
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: line.itemId,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'Item', border: OutlineInputBorder()),
                  items: [
                    for (final it in _items)
                      DropdownMenuItem(value: it['id'] as String, child: Text(it['name'] as String)),
                  ],
                  onChanged: (v) => _pickItem(line, v),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.close),
                onPressed: _lines.length == 1
                    ? null
                    : () => setState(() {
                          _lines.removeAt(i).dispose();
                        }),
              ),
            ]),
            Row(children: [
              Expanded(
                child: TextField(
                  controller: line.qty,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'Qty', border: OutlineInputBorder()),
                  onChanged: (_) => setState(() {}),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: line.rate,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'Rate (Rs.)', border: OutlineInputBorder()),
                  onChanged: (_) => setState(() {}),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  line.itemId == null
                      ? ''
                      : 'GST ${gstLabel(_findItem(line.itemId)?['tax_rate'] as int? ?? 0)}',
                  textAlign: TextAlign.center,
                ),
              ),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _totalRow(String label, String value, {bool bold = false}) {
    final style = TextStyle(fontWeight: bold ? FontWeight.bold : null, fontSize: bold ? 16 : 14);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text(label, style: style), Text(value, style: style)],
      ),
    );
  }
}

// --------------------------------------------------------------- detail

class InvoiceDetailScreen extends StatefulWidget {
  final String invoiceId;
  const InvoiceDetailScreen({super.key, required this.invoiceId});

  @override
  State<InvoiceDetailScreen> createState() => _InvoiceDetailScreenState();
}

class _InvoiceDetailScreenState extends State<InvoiceDetailScreen> {
  Row? _invoice;
  List<Row> _lines = [];
  String _partyName = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final inv = await Repo.invoiceById(widget.invoiceId);
    if (inv == null) return;
    final lines = await Repo.invoiceLines(widget.invoiceId);
    final party = await Repo.partyById(inv['party_id'] as String);
    if (!mounted) return;
    setState(() {
      _invoice = inv;
      _lines = lines;
      _partyName = party?['name'] as String? ?? '';
    });
  }

  Future<void> _sharePdf() async {
    final inv = _invoice;
    if (inv == null) return;
    final business = await Repo.business();
    await shareInvoicePdf(
      business: business,
      invoice: inv,
      lines: _lines,
      partyName: _partyName,
    );
  }

  Future<void> _delete() async {
    final ok = await confirm(
      context,
      'Delete invoice?',
      'The invoice is removed from sales and stock. Payments already received stay on the party account.',
    );
    if (!ok) return;
    await Repo.deleteInvoice(widget.invoiceId);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final inv = _invoice;
    return Scaffold(
      appBar: AppBar(
        title: Text(inv == null ? 'Invoice' : '${inv['invoice_number']}'),
        actions: [
          IconButton(icon: const Icon(Icons.picture_as_pdf), onPressed: inv == null ? null : _sharePdf),
          IconButton(icon: const Icon(Icons.delete_outline), onPressed: inv == null ? null : _delete),
        ],
      ),
      body: inv == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text(_partyName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text('${typeLabel(inv['invoice_type'] as String)} • '
                    '${fmtDate(inv['invoice_date'] as int)} • ${invoiceStatus(inv)}'),
                if ((inv['notes'] as String? ?? '').isNotEmpty) Text('Note: ${inv['notes']}'),
                sectionTitle('Items'),
                for (final l in _lines)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(l['item_name'] as String),
                    subtitle: Text(
                        '${fmtQty(l['quantity'] as num)} ${l['unit'] ?? ''} × ${rs(l['rate'] as int)} '
                        '• GST ${gstLabel(l['tax_rate'] as int)}'),
                    trailing: Text(rs(l['line_total'] as int)),
                  ),
                sectionTitle('Totals'),
                _kv('Subtotal', rs(inv['subtotal'] as int)),
                if ((inv['cgst'] as int) > 0) _kv('CGST', rs(inv['cgst'] as int)),
                if ((inv['sgst'] as int) > 0) _kv('SGST', rs(inv['sgst'] as int)),
                if ((inv['igst'] as int) > 0) _kv('IGST', rs(inv['igst'] as int)),
                _kv('Round off', plain(inv['round_off'] as int)),
                _kv('Total', rs(inv['total'] as int), bold: true),
                if (inv['invoice_type'] != 'estimate') ...[
                  _kv('Paid', rs(inv['amount_paid'] as int)),
                  _kv('Balance due', rs((inv['total'] as int) - (inv['amount_paid'] as int))),
                ],
              ],
            ),
    );
  }

  Widget _kv(String label, String value, {bool bold = false}) {
    final style = TextStyle(fontWeight: bold ? FontWeight.bold : null);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text(label, style: style), Text(value, style: style)],
      ),
    );
  }
}
