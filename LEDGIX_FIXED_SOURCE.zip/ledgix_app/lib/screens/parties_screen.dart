import 'package:flutter/material.dart';

import '../db/repo.dart';
import '../db/row.dart';
import '../utils/format.dart';
import '../widgets/common.dart';
import 'invoices_screen.dart';

// ------------------------------------------------------------------ list

class PartiesScreen extends StatefulWidget {
  const PartiesScreen({super.key});

  @override
  State<PartiesScreen> createState() => _PartiesScreenState();
}

class _PartiesScreenState extends State<PartiesScreen> {
  List<Row> _parties = [];
  Map<String, int> _balances = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final parties = await Repo.parties();
    final balances = await Repo.partyBalances();
    if (!mounted) return;
    setState(() {
      _parties = parties;
      _balances = balances;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_parties.isEmpty) return emptyState('No parties yet. Tap "New party" to add a customer or supplier.');

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.separated(
        itemCount: _parties.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (_, i) {
          final p = _parties[i];
          final bal = _balances[p['id'] as String] ?? 0;
          final name = p['name'] as String;
          return ListTile(
            leading: CircleAvatar(child: Text(name.substring(0, 1).toUpperCase())),
            title: Text(name),
            subtitle: Text(p['party_type'] as String),
            trailing: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(bal == 0 ? 'Settled' : rs(bal.abs()),
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: bal > 0 ? Colors.green : (bal < 0 ? Colors.red : null))),
                if (bal != 0)
                  Text(bal > 0 ? 'to receive' : 'to pay', style: const TextStyle(fontSize: 11)),
              ],
            ),
            onTap: () async {
              await Navigator.push(context,
                  MaterialPageRoute(builder: (_) => PartyDetailScreen(partyId: p['id'] as String)));
              _load();
            },
          );
        },
      ),
    );
  }
}

// ------------------------------------------------------------------ form

class PartyFormScreen extends StatefulWidget {
  final Row? party;
  const PartyFormScreen({super.key, this.party});

  @override
  State<PartyFormScreen> createState() => _PartyFormScreenState();
}

class _PartyFormScreenState extends State<PartyFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _phone;
  late final TextEditingController _email;
  late final TextEditingController _address;
  late final TextEditingController _gstin;
  late final TextEditingController _state;
  late final TextEditingController _opening;
  late String _type;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final p = widget.party ?? {};
    _name = TextEditingController(text: p['name'] ?? '');
    _phone = TextEditingController(text: p['phone'] ?? '');
    _email = TextEditingController(text: p['email'] ?? '');
    _address = TextEditingController(text: p['address'] ?? '');
    _gstin = TextEditingController(text: p['gstin'] ?? '');
    _state = TextEditingController(text: p['state_code'] ?? '');
    final opening = p['opening_balance'] as int?;
    _opening = TextEditingController(
        text: opening == null || opening == 0 ? '' : (opening / 100).toStringAsFixed(2));
    _type = p['party_type'] ?? 'customer';
  }

  @override
  void dispose() {
    for (final c in [_name, _phone, _email, _address, _gstin, _state, _opening]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    final row = <String, dynamic>{
      if (widget.party != null) 'id': widget.party!['id'],
      'name': _name.text.trim(),
      'party_type': _type,
      'phone': _phone.text.trim(),
      'email': _email.text.trim(),
      'address': _address.text.trim(),
      'gstin': _gstin.text.trim().toUpperCase(),
      'state_code': _state.text.trim(),
      'opening_balance': toPaise(_opening.text),
    };
    await Repo.saveParty(row);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.party == null ? 'New party' : 'Edit party')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            textField(_name, 'Name', required: true),
            DropdownButtonFormField<String>(
              value: _type,
              decoration: const InputDecoration(labelText: 'Type', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 'customer', child: Text('Customer')),
                DropdownMenuItem(value: 'supplier', child: Text('Supplier')),
                DropdownMenuItem(value: 'both', child: Text('Both')),
              ],
              onChanged: (v) => setState(() => _type = v ?? 'customer'),
            ),
            const SizedBox(height: 12),
            textField(_phone, 'Phone', keyboard: TextInputType.phone),
            textField(_email, 'Email', keyboard: TextInputType.emailAddress),
            textField(_address, 'Address', maxLines: 2),
            textField(_gstin, 'GSTIN (optional)', hint: '15 characters'),
            textField(_state, 'State code (optional)', keyboard: TextInputType.number,
                hint: 'e.g. 08 for Rajasthan, 27 for Maharashtra'),
            textField(_opening, 'Opening balance (Rs.)',
                keyboard: const TextInputType.numberWithOptions(decimal: true, signed: true),
                hint: '+ party owes you, - you owe party'),
            const SizedBox(height: 8),
            FilledButton(
              onPressed: _saving ? null : _save,
              child: const Text('Save party'),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- detail

class PartyDetailScreen extends StatefulWidget {
  final String partyId;
  const PartyDetailScreen({super.key, required this.partyId});

  @override
  State<PartyDetailScreen> createState() => _PartyDetailScreenState();
}

class _PartyDetailScreenState extends State<PartyDetailScreen> {
  Row? _party;
  int _balance = 0;
  List<Row> _invoices = [];
  List<Row> _payments = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final party = await Repo.partyById(widget.partyId);
    final balance = (await Repo.partyBalances())[widget.partyId] ?? 0;
    final invoices = await Repo.invoices(partyId: widget.partyId);
    final payments = await Repo.payments(partyId: widget.partyId);
    if (!mounted) return;
    setState(() {
      _party = party;
      _balance = balance;
      _invoices = invoices;
      _payments = payments;
    });
  }

  Future<void> _edit() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => PartyFormScreen(party: _party)));
    _load();
  }

  Future<void> _delete() async {
    final ok = await confirm(context, 'Delete party?', 'This party will be removed from the list.');
    if (!ok) return;
    final error = await Repo.deleteParty(widget.partyId);
    if (!mounted) return;
    if (error != null) {
      snack(context, error);
      return;
    }
    Navigator.pop(context);
  }

  Future<void> _pay(String direction) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PaymentFormScreen(
          partyId: widget.partyId,
          partyName: _party?['name'] as String? ?? '',
          direction: direction,
        ),
      ),
    );
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final party = _party;
    return Scaffold(
      appBar: AppBar(
        title: Text(party?['name'] as String? ?? 'Party'),
        actions: [
          IconButton(icon: const Icon(Icons.edit), onPressed: party == null ? null : _edit),
          IconButton(icon: const Icon(Icons.delete_outline), onPressed: party == null ? null : _delete),
        ],
      ),
      body: party == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _balance == 0
                              ? 'Settled'
                              : (_balance > 0
                                  ? 'To receive: ${rs(_balance)}'
                                  : 'To pay: ${rs(-_balance)}'),
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        if ((party['phone'] as String? ?? '').isNotEmpty) Text('Phone: ${party['phone']}'),
                        if ((party['gstin'] as String? ?? '').isNotEmpty) Text('GSTIN: ${party['gstin']}'),
                        if ((party['address'] as String? ?? '').isNotEmpty) Text(party['address'] as String),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(
                    child: FilledButton.tonal(
                      onPressed: () => _pay('in'),
                      child: const Text('Receive payment'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton.tonal(
                      onPressed: () => _pay('out'),
                      child: const Text('Pay party'),
                    ),
                  ),
                ]),
                sectionTitle('Invoices'),
                if (_invoices.isEmpty) const Text('No invoices for this party.'),
                for (final inv in _invoices)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text('${inv['invoice_number']}'),
                    subtitle: Text('${fmtDate(inv['invoice_date'] as int)} • ${invoiceStatus(inv)}'),
                    trailing: Text(rs(inv['total'] as int)),
                    onTap: () async {
                      await Navigator.push(context,
                          MaterialPageRoute(builder: (_) => InvoiceDetailScreen(invoiceId: inv['id'] as String)));
                      _load();
                    },
                  ),
                sectionTitle('Payments'),
                if (_payments.isEmpty) const Text('No payments yet.'),
                for (final p in _payments)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(
                      p['direction'] == 'in' ? Icons.call_received : Icons.call_made,
                      color: p['direction'] == 'in' ? Colors.green : Colors.red,
                    ),
                    title: Text(rs(p['amount'] as int)),
                    subtitle: Text(
                        '${fmtDate(p['payment_date'] as int)} • ${p['mode']}${(p['reference'] as String? ?? '').isEmpty ? '' : ' • ${p['reference']}'}'),
                  ),
              ],
            ),
    );
  }
}

// --------------------------------------------------------------- payment

class PaymentFormScreen extends StatefulWidget {
  final String partyId;
  final String partyName;
  final String direction; // 'in' = receive, 'out' = pay

  const PaymentFormScreen({
    super.key,
    required this.partyId,
    required this.partyName,
    required this.direction,
  });

  @override
  State<PaymentFormScreen> createState() => _PaymentFormScreenState();
}

class _PaymentFormScreenState extends State<PaymentFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _amount = TextEditingController();
  final _reference = TextEditingController();
  final _notes = TextEditingController();
  DateTime _date = DateTime.now();
  String _mode = 'cash';
  bool _saving = false;

  @override
  void dispose() {
    _amount.dispose();
    _reference.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final amount = toPaise(_amount.text);
    if (amount <= 0) {
      snack(context, 'Enter a valid amount');
      return;
    }
    setState(() => _saving = true);
    await Repo.recordPayment(
      partyId: widget.partyId,
      direction: widget.direction,
      amount: amount,
      date: _date.millisecondsSinceEpoch,
      mode: _mode,
      reference: _reference.text.trim(),
      notes: _notes.text.trim(),
    );
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final receiving = widget.direction == 'in';
    return Scaffold(
      appBar: AppBar(
        title: Text(receiving ? 'Receive from ${widget.partyName}' : 'Pay ${widget.partyName}'),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            textField(_amount, 'Amount (Rs.)',
                keyboard: const TextInputType.numberWithOptions(decimal: true), required: true),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text('Date: ${fmtDate(_date.millisecondsSinceEpoch)}'),
              trailing: const Icon(Icons.calendar_today),
              onTap: () async {
                final picked = await showDatePicker(
                  context: context,
                  initialDate: _date,
                  firstDate: DateTime(2020),
                  lastDate: DateTime(2100),
                );
                if (picked != null) setState(() => _date = picked);
              },
            ),
            DropdownButtonFormField<String>(
              value: _mode,
              decoration: const InputDecoration(labelText: 'Mode', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 'cash', child: Text('Cash')),
                DropdownMenuItem(value: 'bank', child: Text('Bank transfer')),
                DropdownMenuItem(value: 'upi', child: Text('UPI')),
                DropdownMenuItem(value: 'cheque', child: Text('Cheque')),
                DropdownMenuItem(value: 'card', child: Text('Card')),
              ],
              onChanged: (v) => setState(() => _mode = v ?? 'cash'),
            ),
            const SizedBox(height: 12),
            textField(_reference, 'Reference (UTR / cheque no.)'),
            textField(_notes, 'Notes'),
            const SizedBox(height: 8),
            FilledButton(
              onPressed: _saving ? null : _save,
              child: Text(receiving ? 'Save receipt' : 'Save payment'),
            ),
          ],
        ),
      ),
    );
  }
}
