import 'package:flutter/material.dart';

import '../db/repo.dart';
import '../utils/format.dart';
import '../widgets/common.dart';
import 'invoices_screen.dart';
import 'items_screen.dart';
import 'parties_screen.dart';
import 'reports_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const _titles = ['Ledgix', 'Invoices', 'Parties', 'Items', 'Reports'];

  int _tab = 0;
  // Bumped after a form closes so the visible tab reloads its data.
  int _version = 0;

  Future<void> _open(Widget page) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
    if (mounted) setState(() => _version++);
  }

  Widget? _fab() {
    switch (_tab) {
      case 1:
        return FloatingActionButton.extended(
          icon: const Icon(Icons.add),
          label: const Text('New invoice'),
          onPressed: () => _open(const InvoiceFormScreen()),
        );
      case 2:
        return FloatingActionButton.extended(
          icon: const Icon(Icons.person_add),
          label: const Text('New party'),
          onPressed: () => _open(const PartyFormScreen()),
        );
      case 3:
        return FloatingActionButton.extended(
          icon: const Icon(Icons.add),
          label: const Text('New item'),
          onPressed: () => _open(const ItemFormScreen()),
        );
      default:
        return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const DashboardTab(),
      const InvoicesScreen(),
      const PartiesScreen(),
      const ItemsScreen(),
      const ReportsScreen(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_tab]),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            tooltip: 'Settings',
            onPressed: () => _open(const SettingsScreen()),
          ),
        ],
      ),
      body: KeyedSubtree(
        key: ValueKey('$_tab-$_version'),
        child: pages[_tab],
      ),
      floatingActionButton: _fab(),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.receipt_long), label: 'Invoices'),
          NavigationDestination(icon: Icon(Icons.people), label: 'Parties'),
          NavigationDestination(icon: Icon(Icons.inventory_2), label: 'Items'),
          NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Reports'),
        ],
      ),
    );
  }
}

class DashboardTab extends StatefulWidget {
  const DashboardTab({super.key});

  @override
  State<DashboardTab> createState() => _DashboardTabState();
}

class _DashboardTabState extends State<DashboardTab> {
  Map<String, int>? _stats;
  bool _setupNeeded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final stats = await Repo.dashboard();
    final business = await Repo.business();
    if (!mounted) return;
    setState(() {
      _stats = stats;
      _setupNeeded = (business['business_name'] ?? '').toString().isEmpty;
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = _stats;
    if (s == null) return const Center(child: CircularProgressIndicator());

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (_setupNeeded)
            Card(
              color: Theme.of(context).colorScheme.errorContainer,
              child: ListTile(
                leading: const Icon(Icons.store),
                title: const Text('Set up your business'),
                subtitle: const Text('Add name, GSTIN and state in Settings so invoices look right.'),
              ),
            ),
          Row(children: [
            Expanded(child: _StatCard('To receive', rs(s['receive']), Colors.green)),
            const SizedBox(width: 12),
            Expanded(child: _StatCard('To pay', rs(s['pay']), Colors.red)),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _StatCard('Sales today', rs(s['sales_today']), null)),
            const SizedBox(width: 12),
            Expanded(child: _StatCard('Sales this month', rs(s['sales_month']), null)),
          ]),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.warning_amber),
              title: const Text('Low stock items'),
              trailing: Text('${s['low_stock']}', style: const TextStyle(fontSize: 18)),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  final Color? color;

  const _StatCard(this.title, this.value, this.color);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 13)),
            const SizedBox(height: 6),
            Text(value,
                style: TextStyle(
                    fontSize: 17, fontWeight: FontWeight.bold, color: color)),
          ],
        ),
      ),
    );
  }
}
