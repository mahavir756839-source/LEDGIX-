import '../db/row.dart';

class InvoiceTotals {
  final List<Row> lines;
  final int subtotal;
  final int cgst;
  final int sgst;
  final int igst;
  final int roundOff;
  final int total;

  const InvoiceTotals({
    required this.lines,
    required this.subtotal,
    required this.cgst,
    required this.sgst,
    required this.igst,
    required this.roundOff,
    required this.total,
  });
}

/// All money is in paise (1 rupee = 100). tax_rate is in basis points (18% = 1800).
///
/// Intra-state (seller and place of supply in same state): CGST + SGST, each half.
/// Inter-state: IGST for the full tax. Total is rounded to the nearest rupee.
InvoiceTotals calculateInvoice({
  required List<Row> items,
  required String sellerState,
  required String placeOfSupply,
}) {
  var subtotal = 0;
  var tax = 0;
  final lines = <Row>[];

  for (final it in items) {
    final qty = (it['quantity'] as num).toDouble();
    final rate = it['rate'] as int;
    final taxRate = it['tax_rate'] as int;

    final taxable = (qty * rate).round();
    final lineTax = (taxable * taxRate + 5000) ~/ 10000;

    subtotal += taxable;
    tax += lineTax;
    lines.add({
      ...it,
      'taxable_amount': taxable,
      'tax_amount': lineTax,
      'line_total': taxable + lineTax,
    });
  }

  final intraState = sellerState.isNotEmpty && sellerState == placeOfSupply;
  final cgst = intraState ? tax ~/ 2 : 0;
  final sgst = intraState ? tax - cgst : 0;
  final igst = intraState ? 0 : tax;

  final before = subtotal + tax;
  final rounded = ((before + 50) ~/ 100) * 100;

  return InvoiceTotals(
    lines: lines,
    subtotal: subtotal,
    cgst: cgst,
    sgst: sgst,
    igst: igst,
    roundOff: rounded - before,
    total: rounded,
  );
}
