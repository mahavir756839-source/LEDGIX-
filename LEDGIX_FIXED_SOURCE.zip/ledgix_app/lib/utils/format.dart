import 'package:intl/intl.dart';

import '../db/row.dart';

final _money = NumberFormat('#,##,##0.00', 'en_IN');
final _dateFmt = DateFormat('dd MMM yyyy');

/// Paise to display, e.g. 123456 -> "Rs. 1,234.56".
String rs(num? paise) => 'Rs. ${_money.format((paise ?? 0) / 100)}';

/// Paise to plain number, e.g. 123456 -> "1,234.56" (for PDF tables).
String plain(num? paise) => _money.format((paise ?? 0) / 100);

String fmtDate(int ms) => _dateFmt.format(DateTime.fromMillisecondsSinceEpoch(ms));

/// Rupee text from user input to paise, e.g. "12.5" -> 1250.
int toPaise(String text) => ((double.tryParse(text.trim()) ?? 0) * 100).round();

String fmtQty(num q) => q == q.roundToDouble() ? q.toInt().toString() : q.toStringAsFixed(2);

String invoiceStatus(Row inv) {
  if (inv['invoice_type'] == 'estimate') return 'Estimate';
  final paid = inv['amount_paid'] as int;
  final total = inv['total'] as int;
  if (paid >= total) return 'Paid';
  if (paid > 0) return 'Partial';
  return 'Unpaid';
}

String typeLabel(String type) =>
    {'sale': 'Sale', 'purchase': 'Purchase', 'estimate': 'Estimate'}[type] ?? type;

const kUnits = ['PCS', 'KG', 'GM', 'LTR', 'MTR', 'BOX', 'NOS', 'SET', 'PAIR', 'SERVICE'];

/// GST rates in basis points.
const kGstRates = [0, 500, 1200, 1800, 2800];

String gstLabel(int bp) => '${(bp / 100).toStringAsFixed(0)}%';
