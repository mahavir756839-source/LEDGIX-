import 'dart:convert';

import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';

import '../utils/calc.dart';
import 'database.dart';
import 'row.dart';

const _prefixes = {'sale': 'INV', 'purchase': 'PUR', 'estimate': 'EST'};

/// All database access goes through this class.
///
/// Every write goes through [_save], which sets sync metadata (version,
/// updated_at) and adds an entry to the outbox in the same transaction.
class Repo {
  static final _uuid = Uuid();

  static String newId() => _uuid.v4();
  static int now() => DateTime.now().millisecondsSinceEpoch;

  static Future<Database> get _db => AppDb.instance.db;

  // ---------------------------------------------------------------- core

  static Future<void> _save(DatabaseExecutor ex, String table, Row row) async {
    final existing = await ex.query(table, where: 'id = ?', whereArgs: [row['id']]);
    final t = now();
    if (existing.isEmpty) {
      row['created_at'] = t;
      row['version'] = 1;
    } else {
      row['created_at'] = existing.first['created_at'];
      row['version'] = (existing.first['version'] as int) + 1;
    }
    row['updated_at'] = t;
    row['is_deleted'] ??= 0;

    await ex.insert(table, row, conflictAlgorithm: ConflictAlgorithm.replace);
    await ex.insert('outbox', {
      'table_name': table,
      'record_id': row['id'],
      'operation': 'upsert',
      'payload': jsonEncode(row),
      'created_at': t,
      'attempts': 0,
    });
  }

  static Future<void> _softDelete(DatabaseExecutor ex, String table, String id) async {
    final rows = await ex.query(table, where: 'id = ?', whereArgs: [id]);
    if (rows.isEmpty) return;
    final row = Map<String, dynamic>.from(rows.first);
    row['is_deleted'] = 1;
    await _save(ex, table, row);
  }

  static Future<int> _count(String sql, List<Object?> args) async {
    return Sqflite.firstIntValue(await (await _db).rawQuery(sql, args)) ?? 0;
  }

  // ------------------------------------------------------------ settings

  static Future<String?> setting(String key) async {
    final rows = await (await _db).query('settings', where: 'key = ?', whereArgs: [key]);
    return rows.isEmpty ? null : rows.first['value'] as String?;
  }

  static Future<Row> business() async {
    final rows = await (await _db).query('settings');
    return {for (final r in rows) r['key'] as String: r['value']};
  }

  static Future<void> saveBusiness(Map<String, String> data) async {
    final d = await _db;
    await d.transaction((txn) async {
      for (final e in data.entries) {
        await txn.insert('settings', {'key': e.key, 'value': e.value},
            conflictAlgorithm: ConflictAlgorithm.replace);
      }
    });
  }

  // ------------------------------------------------------------- parties

  static Future<List<Row>> parties() async {
    return (await _db).query('parties',
        where: 'is_deleted = 0', orderBy: 'name COLLATE NOCASE');
  }

  static Future<Row?> partyById(String id) async {
    final rows = await (await _db).query('parties', where: 'id = ?', whereArgs: [id]);
    return rows.isEmpty ? null : rows.first;
  }

  static Future<void> saveParty(Row row) async {
    row['id'] ??= newId();
    final d = await _db;
    await d.transaction((txn) => _save(txn, 'parties', row));
  }

  /// Returns an error message, or null when deleted.
  static Future<String?> deleteParty(String id) async {
    final invoices = await _count(
        'SELECT COUNT(*) FROM invoices WHERE party_id = ? AND is_deleted = 0', [id]);
    final payments = await _count(
        'SELECT COUNT(*) FROM payments WHERE party_id = ? AND is_deleted = 0', [id]);
    if (invoices + payments > 0) {
      return 'This party has invoices or payments and cannot be deleted.';
    }
    final d = await _db;
    await d.transaction((txn) => _softDelete(txn, 'parties', id));
    return null;
  }

  /// Positive = party owes you (receivable). Negative = you owe party (payable).
  static Future<Map<String, int>> partyBalances() async {
    final d = await _db;
    final balances = <String, int>{};
    final parties = await d.query('parties', where: 'is_deleted = 0');
    for (final p in parties) {
      balances[p['id'] as String] = p['opening_balance'] as int;
    }

    Future<void> addSum(String sql, int sign) async {
      for (final r in await d.rawQuery(sql)) {
        final id = r['party_id'] as String?;
        if (id == null || !balances.containsKey(id)) continue;
        balances[id] = balances[id]! + sign * ((r['s'] as num?)?.toInt() ?? 0);
      }
    }

    await addSum(
        "SELECT party_id, SUM(total) AS s FROM invoices WHERE invoice_type = 'sale' "
        "AND status = 'final' AND is_deleted = 0 GROUP BY party_id", 1);
    await addSum(
        "SELECT party_id, SUM(total) AS s FROM invoices WHERE invoice_type = 'purchase' "
        "AND status = 'final' AND is_deleted = 0 GROUP BY party_id", -1);
    await addSum(
        "SELECT party_id, SUM(amount) AS s FROM payments WHERE direction = 'in' "
        "AND is_deleted = 0 GROUP BY party_id", -1);
    await addSum(
        "SELECT party_id, SUM(amount) AS s FROM payments WHERE direction = 'out' "
        "AND is_deleted = 0 GROUP BY party_id", 1);
    return balances;
  }

  // --------------------------------------------------------------- items

  static Future<List<Row>> items() async {
    return (await _db).query('items', where: 'is_deleted = 0', orderBy: 'name COLLATE NOCASE');
  }

  static Future<void> saveItem(Row row) async {
    row['id'] ??= newId();
    final d = await _db;
    await d.transaction((txn) => _save(txn, 'items', row));
  }

  static Future<void> deleteItem(String id) async {
    final d = await _db;
    await d.transaction((txn) => _softDelete(txn, 'items', id));
  }

  /// Current stock per item id: opening stock + purchases - sales.
  static Future<Map<String, double>> stocks() async {
    final d = await _db;
    final itemRows = await d.query('items', where: 'is_deleted = 0');
    final moved = await d.rawQuery('''
      SELECT ii.item_id AS item_id,
             COALESCE(SUM(CASE WHEN i.invoice_type = 'purchase' THEN ii.quantity
                               WHEN i.invoice_type = 'sale' THEN -ii.quantity
                               ELSE 0 END), 0) AS q
      FROM invoice_items ii
      JOIN invoices i ON i.id = ii.invoice_id
      WHERE i.is_deleted = 0 AND i.status = 'final' AND ii.item_id IS NOT NULL
      GROUP BY ii.item_id''');
    final movedMap = {
      for (final r in moved) r['item_id'] as String: (r['q'] as num).toDouble()
    };
    return {
      for (final it in itemRows)
        it['id'] as String: (it['opening_stock'] as num).toDouble() +
            (movedMap[it['id'] as String] ?? 0)
    };
  }

  // ------------------------------------------------------------ invoices

  static Future<List<Row>> invoices({String? type, String? partyId}) async {
    final where = <String>['i.is_deleted = 0'];
    final args = <Object?>[];
    if (type != null) {
      where.add('i.invoice_type = ?');
      args.add(type);
    }
    if (partyId != null) {
      where.add('i.party_id = ?');
      args.add(partyId);
    }
    return (await _db).rawQuery('''
      SELECT i.*, p.name AS party_name
      FROM invoices i
      LEFT JOIN parties p ON p.id = i.party_id
      WHERE ${where.join(' AND ')}
      ORDER BY i.invoice_date DESC, i.invoice_number DESC''', args);
  }

  static Future<Row?> invoiceById(String id) async {
    final rows = await (await _db).query('invoices', where: 'id = ?', whereArgs: [id]);
    return rows.isEmpty ? null : rows.first;
  }

  static Future<List<Row>> invoiceLines(String invoiceId) async {
    return (await _db).query('invoice_items',
        where: 'invoice_id = ?', whereArgs: [invoiceId], orderBy: 'line_order');
  }

  /// Invoice numbers never repeat: counts deleted invoices too.
  static Future<String> _nextNumber(DatabaseExecutor ex, String type, int date) async {
    final prefix = _prefixes[type]!;
    final year = DateTime.fromMillisecondsSinceEpoch(date).year;
    final c = Sqflite.firstIntValue(await ex.rawQuery(
            'SELECT COUNT(*) FROM invoices WHERE invoice_type = ? AND invoice_number LIKE ?',
            [type, '$prefix-$year-%'])) ??
        0;
    return '$prefix-$year-${(c + 1).toString().padLeft(4, '0')}';
  }

  /// [lines] needs: item_id, item_name, hsn_code, unit, quantity, rate, tax_rate.
  static Future<String> createInvoice({
    required String type,
    required String partyId,
    required int date,
    required String placeOfSupply,
    required List<Row> lines,
    String? notes,
    int receivedNow = 0,
    String mode = 'cash',
  }) async {
    if (lines.isEmpty) throw Exception('Add at least one item');
    final sellerState = await setting('state_code') ?? '';
    final totals = calculateInvoice(
        items: lines, sellerState: sellerState, placeOfSupply: placeOfSupply);

    final id = newId();
    final d = await _db;
    late String number;
    await d.transaction((txn) async {
      number = await _nextNumber(txn, type, date);
      await _save(txn, 'invoices', {
        'id': id,
        'invoice_type': type,
        'invoice_number': number,
        'party_id': partyId,
        'invoice_date': date,
        'place_of_supply': placeOfSupply,
        'subtotal': totals.subtotal,
        'cgst': totals.cgst,
        'sgst': totals.sgst,
        'igst': totals.igst,
        'round_off': totals.roundOff,
        'total': totals.total,
        'amount_paid': 0,
        'status': 'final',
        'notes': notes,
      });
      for (var i = 0; i < totals.lines.length; i++) {
        final l = totals.lines[i];
        await _save(txn, 'invoice_items', {
          'id': newId(),
          'invoice_id': id,
          'item_id': l['item_id'],
          'item_name': l['item_name'],
          'hsn_code': l['hsn_code'],
          'unit': l['unit'],
          'quantity': l['quantity'],
          'rate': l['rate'],
          'tax_rate': l['tax_rate'],
          'taxable_amount': l['taxable_amount'],
          'tax_amount': l['tax_amount'],
          'line_total': l['line_total'],
          'line_order': i,
        });
      }
      if (receivedNow > 0 && (type == 'sale' || type == 'purchase')) {
        await _recordPayment(txn,
            partyId: partyId,
            direction: type == 'sale' ? 'in' : 'out',
            amount: receivedNow,
            date: date,
            mode: mode,
            notes: 'Received with $number');
      }
    });
    return number;
  }

  /// Soft delete. Payments stay on the party, so the balance remains correct.
  static Future<void> deleteInvoice(String id) async {
    final d = await _db;
    await d.transaction((txn) => _softDelete(txn, 'invoices', id));
  }

  // ------------------------------------------------------------ payments

  static Future<List<Row>> payments({String? partyId}) async {
    return (await _db).query('payments',
        where: partyId == null ? 'is_deleted = 0' : 'is_deleted = 0 AND party_id = ?',
        whereArgs: partyId == null ? null : [partyId],
        orderBy: 'payment_date DESC');
  }

  static Future<void> recordPayment({
    required String partyId,
    required String direction, // 'in' or 'out'
    required int amount,
    required int date,
    String mode = 'cash',
    String? reference,
    String? notes,
  }) async {
    final d = await _db;
    await d.transaction((txn) => _recordPayment(txn,
        partyId: partyId,
        direction: direction,
        amount: amount,
        date: date,
        mode: mode,
        reference: reference,
        notes: notes));
  }

  /// Saves the payment, then marks it against the oldest unpaid invoices (FIFO).
  static Future<void> _recordPayment(
    DatabaseExecutor ex, {
    required String partyId,
    required String direction,
    required int amount,
    required int date,
    String mode = 'cash',
    String? reference,
    String? notes,
  }) async {
    await _save(ex, 'payments', {
      'id': newId(),
      'party_id': partyId,
      'direction': direction,
      'amount': amount,
      'payment_date': date,
      'mode': mode,
      'reference': reference,
      'notes': notes,
    });

    var remaining = amount;
    final type = direction == 'in' ? 'sale' : 'purchase';
    final open = await ex.query('invoices',
        where: "party_id = ? AND invoice_type = ? AND status = 'final' "
            "AND is_deleted = 0 AND amount_paid < total",
        whereArgs: [partyId, type],
        orderBy: 'invoice_date ASC, invoice_number ASC');
    for (final inv in open) {
      if (remaining <= 0) break;
      final due = (inv['total'] as int) - (inv['amount_paid'] as int);
      final pay = remaining < due ? remaining : due;
      final row = Map<String, dynamic>.from(inv);
      row['amount_paid'] = (inv['amount_paid'] as int) + pay;
      await _save(ex, 'invoices', row);
      remaining -= pay;
    }
  }

  // ----------------------------------------------------------- dashboard

  static Future<int> _sumSales(String type, int fromMs) async {
    return Sqflite.firstIntValue(await (await _db).rawQuery(
            "SELECT COALESCE(SUM(total), 0) FROM invoices WHERE invoice_type = ? "
            "AND status = 'final' AND is_deleted = 0 AND invoice_date >= ?",
            [type, fromMs])) ??
        0;
  }

  static Future<Map<String, int>> dashboard() async {
    final balances = await partyBalances();
    var receive = 0;
    var pay = 0;
    for (final b in balances.values) {
      if (b > 0) {
        receive += b;
      } else {
        pay += -b;
      }
    }

    final today = DateTime.now();
    final dayStart = DateTime(today.year, today.month, today.day).millisecondsSinceEpoch;
    final monthStart = DateTime(today.year, today.month, 1).millisecondsSinceEpoch;

    final itemRows = await items();
    final stockMap = await stocks();
    var lowStock = 0;
    for (final it in itemRows) {
      final minStock = (it['min_stock'] as num).toDouble();
      if (it['track_stock'] == 1 &&
          minStock > 0 &&
          (stockMap[it['id'] as String] ?? 0) <= minStock) {
        lowStock++;
      }
    }

    return {
      'receive': receive,
      'pay': pay,
      'sales_today': await _sumSales('sale', dayStart),
      'sales_month': await _sumSales('sale', monthStart),
      'low_stock': lowStock,
    };
  }

  // -------------------------------------------------------------- reports

  /// Totals per invoice type between two epoch-ms values (inclusive).
  static Future<List<Row>> salesSummary(int fromMs, int toMs) async {
    return (await _db).rawQuery('''
      SELECT invoice_type,
             COUNT(*) AS cnt,
             COALESCE(SUM(subtotal), 0) AS subtotal,
             COALESCE(SUM(cgst), 0) AS cgst,
             COALESCE(SUM(sgst), 0) AS sgst,
             COALESCE(SUM(igst), 0) AS igst,
             COALESCE(SUM(total), 0) AS total
      FROM invoices
      WHERE status = 'final' AND is_deleted = 0
        AND invoice_type IN ('sale', 'purchase')
        AND invoice_date BETWEEN ? AND ?
      GROUP BY invoice_type''', [fromMs, toMs]);
  }

  // --------------------------------------------------------------- backup

  static Future<Map<String, List<Row>>> exportAll() async {
    final d = await _db;
    final out = <String, List<Row>>{};
    for (final table in ['settings', 'parties', 'items', 'invoices', 'invoice_items', 'payments']) {
      out[table] = await d.query(table);
    }
    return out;
  }
}
