/// One database row / record as a generic map.
typedef Row = Map<String, dynamic>;
