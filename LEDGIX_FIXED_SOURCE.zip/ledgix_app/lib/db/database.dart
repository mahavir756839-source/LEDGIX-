import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

/// Columns every syncable table has (used later by cloud sync).
const _sync = 'created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, '
    'is_deleted INTEGER NOT NULL DEFAULT 0, version INTEGER NOT NULL DEFAULT 1';

final List<String> _schema = [
  'CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT)',
  '''CREATE TABLE parties (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    party_type TEXT NOT NULL DEFAULT 'customer',
    phone TEXT, email TEXT, address TEXT, gstin TEXT, state_code TEXT,
    opening_balance INTEGER NOT NULL DEFAULT 0,
    $_sync)''',
  '''CREATE TABLE items (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    item_code TEXT,
    item_type TEXT NOT NULL DEFAULT 'product',
    hsn_code TEXT,
    unit TEXT NOT NULL DEFAULT 'PCS',
    sale_price INTEGER NOT NULL DEFAULT 0,
    purchase_price INTEGER NOT NULL DEFAULT 0,
    tax_rate INTEGER NOT NULL DEFAULT 0,
    track_stock INTEGER NOT NULL DEFAULT 1,
    opening_stock REAL NOT NULL DEFAULT 0,
    min_stock REAL NOT NULL DEFAULT 0,
    $_sync)''',
  '''CREATE TABLE invoices (
    id TEXT PRIMARY KEY,
    invoice_type TEXT NOT NULL,
    invoice_number TEXT NOT NULL,
    party_id TEXT NOT NULL,
    invoice_date INTEGER NOT NULL,
    place_of_supply TEXT,
    subtotal INTEGER NOT NULL DEFAULT 0,
    cgst INTEGER NOT NULL DEFAULT 0,
    sgst INTEGER NOT NULL DEFAULT 0,
    igst INTEGER NOT NULL DEFAULT 0,
    round_off INTEGER NOT NULL DEFAULT 0,
    total INTEGER NOT NULL DEFAULT 0,
    amount_paid INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'final',
    notes TEXT,
    $_sync,
    FOREIGN KEY (party_id) REFERENCES parties(id))''',
  '''CREATE TABLE invoice_items (
    id TEXT PRIMARY KEY,
    invoice_id TEXT NOT NULL,
    item_id TEXT,
    item_name TEXT NOT NULL,
    hsn_code TEXT,
    unit TEXT,
    quantity REAL NOT NULL,
    rate INTEGER NOT NULL,
    tax_rate INTEGER NOT NULL,
    taxable_amount INTEGER NOT NULL,
    tax_amount INTEGER NOT NULL,
    line_total INTEGER NOT NULL,
    line_order INTEGER NOT NULL DEFAULT 0,
    $_sync,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id))''',
  '''CREATE TABLE payments (
    id TEXT PRIMARY KEY,
    party_id TEXT NOT NULL,
    direction TEXT NOT NULL,
    amount INTEGER NOT NULL,
    payment_date INTEGER NOT NULL,
    mode TEXT NOT NULL DEFAULT 'cash',
    reference TEXT,
    notes TEXT,
    $_sync,
    FOREIGN KEY (party_id) REFERENCES parties(id))''',
  '''CREATE TABLE outbox (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    table_name TEXT NOT NULL,
    record_id TEXT NOT NULL,
    operation TEXT NOT NULL,
    payload TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0)''',
];

class AppDb {
  AppDb._();
  static final AppDb instance = AppDb._();

  Database? _db;

  Future<Database> get db async {
    _db ??= await _open();
    return _db!;
  }

  Future<Database> _open() async {
    final path = join(await getDatabasesPath(), 'ledgix.db');
    return openDatabase(
      path,
      version: 1,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, version) async {
        for (final statement in _schema) {
          await db.execute(statement);
        }
      },
    );
  }
}
