# LEDGIX

Free, offline-first billing and accounting app for small businesses, built with Flutter. Data is stored locally on the phone in SQLite.

## Included features (v1.0)

- Business profile (name, GSTIN, state code, address)
- Parties: customers and suppliers, opening balance, GSTIN, state
- Items: product or service, HSN, unit, GST rate, sale and purchase price, stock tracking, low stock alert
- Invoices: sale, purchase and estimate, with automatic numbering
- GST: CGST + SGST for same state, IGST for other states, round off to rupee
- Payments: receive from customer or pay supplier, allocated to oldest unpaid invoices (FIFO)
- Dashboard: receivables, payables, sales and low stock count
- Reports: sales and purchase totals, GST summary, outstanding balances, date range
- PDF invoice and system share sheet
- JSON backup export

## Build APK on GitHub Actions

This source ZIP does not contain an Android Gradle project. The included workflow creates the Android project shell automatically, then gets packages, runs tests and analysis, builds the debug APK, verifies it, and uploads it as a GitHub Actions artifact.

1. Upload `ledgix_app.zip` to the root of your GitHub repository.
2. Copy `.github/workflows/build.yml` from this ZIP into the same path in the GitHub repository: `.github/workflows/build.yml`.
3. Open the repository's **Actions** tab.
4. Select **LEDGIX Flutter APK Build** and tap **Run workflow** (or push a change to trigger it).
5. When the run succeeds, open it and download the **LEDGIX-debug-APK** artifact. Extract it to get `app-debug.apk`.

The workflow intentionally stops if tests or `flutter analyze` report errors; it does not upload a broken APK.

## Build locally

Install Flutter stable, then run:

```bash
flutter create --no-pub --platforms=android --org com.ledgix --project-name ledgix .
flutter pub get
flutter test
flutter analyze
flutter build apk --debug
```

APK output: `build/app/outputs/flutter-apk/app-debug.apk`.

## Project layout

```text
lib/
  main.dart
  db/                 SQLite schema and repository
  screens/            Dashboard, invoices, parties, items, reports, settings
  services/           PDF and backup services
  utils/              GST calculations and formatting
  widgets/            Shared widgets
test/
  calc_test.dart      GST calculation tests
.github/workflows/
  build.yml           GitHub Actions APK build
```

## Not yet included

Cloud sync, backup restore, returns, expenses, bank accounts, multi-user support, and invoice editing are not included in this version.

## Important

This first version should be tested carefully before using it for real accounting. Verify GST treatment and invoice formats with a qualified CA.
