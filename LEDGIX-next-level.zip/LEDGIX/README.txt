Accounting of LEDGIX - Smart Billing & Accounts (Android app)
===============================================================

App ka naam:
- Phone par (home screen / app drawer): LEDGIX
- Print, PDF share aur logo picker me: Accounting of LEDGIX
- Play Store listing title: Accounting of LEDGIX (Play Console me enter karna hota hai,
  APK se nahi aata)
Bill par dikhne wala firm ka naam Masters > Firm details me badal sakte ho
(default: LEDGIX).

Ye ek Android WebView app hai. App ke andar ek billing + accounts screen hai
(app/src/main/assets/ledgix.html). Android Studio ya GitHub Actions dono se APK banta hai.

APK kaise banayein
------------------
A) Android Studio:
   1. File > Open > is LEDGIX folder ko chuno.
   2. Gradle sync hone do (pehli baar internet chahiye).
   3. Build > Build APK(s). APK: app/build/outputs/apk/debug/app-debug.apk

B) GitHub Actions (bina Android Studio ke):
   1. Is folder ko ek GitHub repository me upload karo (structure same rakhna).
   2. Actions tab me "Build APK" workflow chalega.
   3. Artifact "LEDGIX-apk" download karo, usme se LEDGIX-debug.apk install karo.

App icon / splash
-----------------
- Launcher icon: LEDGIX gold "L" icon (mipmap-* folders, adaptive background #060C18).
- Splash: LEDGIX poster (drawable-nodpi/splash_logo.png).
- Header icon: app/src/main/assets/app-icon.png

Features (ledgix.html)
----------------------
- New Bill: Sale / Purchase, GST (CGST+SGST ya IGST), item-wise HSN, stock auto update.
- Bills & Payments: payment/receipt, advance, bill-wise settlement.
- Party Summary, Party Ledger (Dr/Cr).
- Stock: material-wise in / out / closing.
- Expenses (kharche ke heads):
  * kharche ke heads (Rent, Fuel, Freight...), apne heads add/delete
  * Expense register (mahine-wise, head-wise), Head ledger
- Day Book: date-wise sab entries (Sales, Purchase, Receipt, Payment, Expense, Salary)
- Profit & Loss: Sales, Purchases, Expenses, Salary se Net Profit/Loss
  (stock valuation shamil nahi, GST ke bina taxable value)
- Salary: employee, monthly salary sheet, advance/payment.
- Masters: firm details + logo (gallery se), parties, materials.
- Invoice aur Challan: 10 + 10 designs.
  * Masters me gallery se firm ka default design chuno (naye bills par lagega).
  * Har bill ki preview me alag design chun sakte ho (ye us bill me save hota hai).
  * RE-6 form (govt format) ka layout fixed hai.
- PDF share: invoice aur challan dono. Internet chahiye (jsPDF + html2canvas CDN).
  Offline ho to Print / PDF se save karo.

Data
----
- Data app ke local storage me rehta hai (phone se bahar nahi jaata).
- Key: "ledgix". Purana data (purani key) pehli baar khulne par apne aap uthaya jata hai,
  lekin sirf usi app install par jisme wo data bana tha.
- Package id: com.ledgix.accounting (Play Store ke liye zaroori; com.example.* allowed nahi hai).
  Is id se pehle wala app alag app hai, purana data isme nahi aata.

Play Store par upload
---------------------
1. Play Console me new app banao. App name: Accounting of LEDGIX
2. Debug APK nahi, signed release AAB chahiye: Android Studio me
   Build > Generate Signed App Bundle / APK > Android App Bundle.
   Keystore file aur password safe rakho, wahi har update me lagega.
3. Har upload par versionCode (app/build.gradle.kts) badhana padta hai.
4. Play Console ki latest targetSdk requirement check karo (abhi targetSdk = 34).

Files
-----
- app/src/main/assets/ledgix.html   : poora app (UI + logic)
- app/src/main/java/...             : Kotlin (WebView, file picker, PDF share bridge)
- app/src/main/res/                 : icons, splash, colors
