package com.ledgix.accounting

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.ComponentActivity
import kotlin.math.cos
import kotlin.math.sin

class SplashActivity : ComponentActivity() {

    private val handler = Handler(Looper.getMainLooper())

    private val openMain = Runnable {
        startActivity(Intent(this, MainActivity::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val density = resources.displayMetrics.density
        val root = FrameLayout(this)

        // Gehra navy background, beech mein halki roshni (radial glow)
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#0b1a33"), Color.parseColor("#050814"))
        )

        // Glow ring: logo ke peeche pulse karti roshni
        val glow = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                colors = intArrayOf(Color.parseColor("#66D4AF37"), Color.parseColor("#00D4AF37"))
                gradientType = GradientDrawable.RADIAL_GRADIENT
                gradientRadius = 260f * density
            }
            alpha = 0f; scaleX = 0.4f; scaleY = 0.4f
        }
        root.addView(glow, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // Logo (shuru mein chhupa)
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.splash_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            alpha = 0f; scaleX = 0.5f; scaleY = 0.5f
        }
        root.addView(logo, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // Shine sweep: logo par ek chamakti line guzarti hai
        val shine = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.TRANSPARENT, Color.parseColor("#55FFFFFF"), Color.TRANSPARENT)
            )
            alpha = 0f
        }
        val shineW = (resources.displayMetrics.widthPixels * 0.35f).toInt()
        root.addView(shine, FrameLayout.LayoutParams(shineW, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.START))

        // Chhote icons: chaaron taraf se aakar ghoomte hue ek jagah jama hote hain
        val icons = listOf("🧾", "📄", "💰", "📦", "🚚", "📊").mapIndexed { i, emoji ->
            val angle = Math.toRadians(i * 60.0)
            val dist = 210f * density
            TextView(this).apply {
                text = emoji
                textSize = 26f
                gravity = Gravity.CENTER
                translationX = (cos(angle) * dist).toFloat()
                translationY = (sin(angle) * dist).toFloat()
                alpha = 0f; scaleX = 0.4f; scaleY = 0.4f
            }
        }
        icons.forEach { root.addView(it, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER)) }
        setContentView(root)

        // 1) Icons aate hain aur ghoomte hue andar girte hain (0 - 800ms)
        icons.forEachIndexed { i, v ->
            v.animate()
                .translationX(0f).translationY(0f)
                .rotationBy(360f + i * 30f)
                .alpha(1f).scaleX(1f).scaleY(1f)
                .setStartDelay(i * 70L)
                .setDuration(700)
                .setInterpolator(AccelerateDecelerateInterpolator())
                .withEndAction {
                    // 2) Icon gayab hote hain, ek chamak nikalti hai
                    v.animate().alpha(0f).scaleX(0.2f).scaleY(0.2f).setDuration(180).start()
                }.start()
        }

        // 3) Glow phailta hai aur logo zoom-in hota hai (700ms se)
        handler.postDelayed({
            glow.animate().alpha(1f).scaleX(1.25f).scaleY(1.25f).setDuration(700).start()
            logo.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(800).setInterpolator(OvershootInterpolator(1.3f)).start()
        }, 700L)

        // 4) Shine logo ke upar se guzarti hai (1300ms se)
        handler.postDelayed({
            shine.alpha = 1f
            shine.translationX = -shineW.toFloat()
            shine.animate().translationX(resources.displayMetrics.widthPixels.toFloat())
                .setDuration(650).withEndAction { shine.alpha = 0f }.start()
        }, 1300L)

        // 5) Glow halka pulse karta hai (ruk kar)
        handler.postDelayed({
            glow.animate().alpha(0.6f).setDuration(400).withEndAction {
                glow.animate().alpha(1f).setDuration(400).start()
            }.start()
        }, 1700L)

        handler.postDelayed(openMain, SPLASH_DURATION_MS)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    companion object {
        private const val SPLASH_DURATION_MS = 2600L
    }
}
