package com.ledgix.accounting

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.ComponentActivity
import kotlin.math.cos
import kotlin.math.sin

class SplashActivity : ComponentActivity() {

    private val handler = Handler(Looper.getMainLooper())

    private val openMain = Runnable {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#050814")) }

        // Logo (shuru mein chhupa hota hai)
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.splash_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            alpha = 0f
            scaleX = 0.6f
            scaleY = 0.6f
        }
        root.addView(logo, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // Chhote icons: bahar se aakar ek jagah jama hote hain
        val density = resources.displayMetrics.density
        val icons = listOf("🧾", "📄", "💰", "📦", "🚚", "📊").mapIndexed { i, emoji ->
            val angle = Math.toRadians(i * 60.0)
            val dist = 180f * density
            TextView(this).apply {
                text = emoji
                textSize = 30f
                gravity = Gravity.CENTER
                translationX = (cos(angle) * dist).toFloat()
                translationY = (sin(angle) * dist).toFloat()
                alpha = 0f
            }
        }
        icons.forEach { root.addView(it, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER)) }
        setContentView(root)

        // 1) Icons andar aate hain  2) Icons gayab, logo zoom-in  3) App khulti hai
        icons.forEachIndexed { i, v ->
            v.animate().translationX(0f).translationY(0f).alpha(1f)
                .setStartDelay(i * 60L).setDuration(600)
                .withEndAction {
                    v.animate().alpha(0f).scaleX(0.3f).scaleY(0.3f).setDuration(200).start()
                }.start()
        }
        handler.postDelayed({
            logo.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(700).setInterpolator(OvershootInterpolator(1.2f)).start()
        }, 700L)
        handler.postDelayed(openMain, SPLASH_DURATION_MS)
    }

    override fun onDestroy() {
        handler.removeCallbacks(openMain)
        super.onDestroy()
    }

    companion object {
        private const val SPLASH_DURATION_MS = 2200L
    }
}
