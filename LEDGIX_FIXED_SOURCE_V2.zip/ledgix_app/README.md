# LEDGIX Flutter source

## GitHub Actions APK build

1. Upload this ZIP to the repository root. The workflow below supports both `LEDGIX_FIXED_SOURCE.zip` and `ledgix_app.zip`.
2. IMPORTANT: replace the workflow file in the GitHub repository itself at `.github/workflows/build.yml` with the `LEDGIX_build.yml` file included alongside this ZIP (or copy `ledgix_app/.github/workflows/build.yml` to that exact repository path).
3. Open Actions → LEDGIX Flutter APK Build → Run workflow.
4. Download the `LEDGIX-debug-APK` artifact after a successful run.

The workflow extracts the Flutter source, generates the Android platform files with `flutter create`, runs `flutter pub get`, builds the debug APK, verifies it, and uploads it. Unit tests and static analysis run afterward as report-only steps and do not block APK upload.

APK path: `build/app/outputs/flutter-apk/app-debug.apk`.
