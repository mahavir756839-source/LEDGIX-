# Ledgix

Free billing and accounting app for small businesses (Android, Flutter).
Offline-first. Data is stored on the phone in SQLite.

## Features (v1.0)

- Business profile (name, GSTIN, state code, address)
- Parties: customers and suppliers, opening balance, GSTIN, state
- Items: product or service, HSN, unit, GST rate, sale and purchase price, stock tracking, low stock alert
- Invoices: sale, purchase and estimate, with auto numbering (INV-2026-0001)
- GST: CGST + SGST for same state, IGST for other states, round off to rupee
- Payments: receive from customer or pay supplier, auto-allocated to oldest unpaid invoices (FIFO)
- Dashboard: to receive, to pay, sales today and this month, low stock count
- Reports: sales and purchase totals, GST summary, outstanding balances, for any date range
- PDF invoice, shared via the system share sheet
- JSON backup export
- Delete invoice (soft delete) and party/item

## Not yet included (planned)

- Cloud sync. Each change is already written to the `outbox` table, so the sync engine
  can be added later without changing the data model.
- Backup restore (import JSON).
- Returns (sale and purchase return), expenses, bank accounts, multi-user.
- Invoice edit. Final invoices are not edited. Delete and re-create instead.

## Setup

You need Flutter (stable), Android Studio or an Android phone with USB debugging.

```bash
# 1. Create the Android project shell (once)
flutter create --org com.ledgix --project-name ledgix ledgix_app

# 2. Copy this folder's contents over the generated project
#    Replace lib/, test/ and pubspec.yaml with the ones in this folder.
cd ledgix_app
rm -rf lib test
cp -r /path/to/ledgix_app/lib /path/to/ledgix_app/test .
cp /path/to/ledgix_app/pubspec.yaml .

# 3. Install packages
flutter pub get

# 4. Run unit tests (GST logic)
flutter test

# 5. Run on a phone or emulator
flutter run
```

Building a release APK for installing:

```bash
flutter build apk --release
# Output: build/app/outputs/flutter-apk/app-release.apk
```

## Project layout

```
lib/
  main.dart                  App entry
  db/
    database.dart            SQLite schema (tables, sync columns, outbox)
    repo.dart                All reads and writes, balances, stock, FIFO payments
    row.dart                 Row type alias
  utils/
    calc.dart                GST and invoice totals (pure logic, tested)
    format.dart              Money, date, status, units and GST rate helpers
  widgets/common.dart        Shared form fields and dialogs
  screens/
    home_screen.dart         Bottom navigation and dashboard
    invoices_screen.dart     Invoice list, new invoice form, invoice detail
    parties_screen.dart      Party list, form, detail, payment form
    items_screen.dart        Item list and form
    reports_screen.dart      Reports for a date range
    settings_screen.dart     Business profile and backup
  services/
    pdf_service.dart         Invoice PDF
    backup_service.dart      JSON backup export
test/
  calc_test.dart             GST unit tests
```

## Money and tax rules

- All money is stored as integer paise (Rs. 1 = 100). No floating point money.
- Tax rates are basis points (18% = 1800).
- Final invoices are not edited. Delete soft-deletes them, and their payments stay on the party.
- Stock = opening stock + purchases - sales (final invoices only).
- Party balance: positive means the party owes you. Negative means you owe them.

## Notes on this first version

- The app was written without a running Flutter device in the build environment, so the
  first `flutter run` may show small compile fixes (for example, package version changes).
  Run `flutter analyze` and fix anything it reports.
- Use your own app name, icon and package id before publishing to Play Store.
- Check GST rules and invoice format with a CA before using in a real business.
