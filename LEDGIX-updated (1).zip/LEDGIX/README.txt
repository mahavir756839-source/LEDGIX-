Accounting of LEDGIX - Smart Billing & Accounts (Android app)
===============================================================

App ka naam:
- Phone par (home screen / app drawer): LEDGIX
- Print, PDF share aur logo picker me: Accounting of LEDGIX
- Play Store listing title: Accounting of LEDGIX (Play Console me enter karna hota hai,
  APK se nahi aata)
Bill par dikhne wala firm ka naam Masters > Firm details me badal sakte ho
(default: LEDGIX).

Ye ek Android WebView app hai. App ke andar ek billing + accounts screen hai
(app/src/main/assets/ledgix.html). Android Studio ya GitHub Actions dono se APK banta hai.

APK kaise banayein
------------------
A) Android Studio:
   1. File > Open > is LEDGIX folder ko chuno.
   2. Gradle sync hone do (pehli baar internet chahiye).
   3. Build > Build APK(s). APK: app/build/outputs/apk/debug/app-debug.apk

B) GitHub Actions (bina Android Studio ke):
   1. Is folder ko ek GitHub repository me upload karo (structure same rakhna).
   2. Actions tab me "Build APK" workflow chalega.
   3. Artifact "LEDGIX-apk" download karo, usme se LEDGIX-debug.apk install karo.

App icon / splash
-----------------
- Launcher icon: LEDGIX gold "L" icon (mipmap-* folders, adaptive background #060C18).
- Splash: LEDGIX poster (drawable-nodpi/splash_logo.png).
- Header icon: app/src/main/assets/app-icon.png

Features (ledgix.html)
----------------------
- New Bill: Sale / Purchase, GST (CGST+SGST ya IGST), item-wise HSN, stock auto update.
- Bills & Payments: payment/receipt, advance, bill-wise settlement.
- Party Summary, Party Ledger (Tally jaisa Dr/Cr).
- Stock: material-wise in / out / closing.
- Expenses (Tally ke Indirect Expenses ki tarah):
  * kharche ke heads (Rent, Fuel, Freight...), apne heads add/delete
  * Expense register (mahine-wise, head-wise), Head ledger
- Day Book: date-wise sab entries (Sales, Purchase, Receipt, Payment, Expense, Salary)
- Profit & Loss: Sales, Purchases, Expenses, Salary se Net Profit/Loss
  (stock valuation shamil nahi, GST ke bina taxable value)
- Salary: employee, monthly salary sheet, advance/payment.
- Masters: firm details + logo (gallery se), parties, materials.
- Invoice aur Challan: 10 + 10 designs.
  * Masters me gallery se firm ka default design chuno (naye bills par lagega).
  * Har bill ki preview me alag design chun sakte ho (ye us bill me save hota hai).
  * RE-6 form (govt format) ka layout fixed hai.
- PDF share: invoice aur challan dono. Internet chahiye (jsPDF + html2canvas CDN).
  Offline ho to Print / PDF se save karo.

Data
----
- Data app ke local storage me rehta hai (phone se bahar nahi jaata).
- Key: "ledgix". Purana data (key "bajrangTally") pehli baar khulne par apne aap uthaya jata hai,
  lekin sirf usi app install par jisme wo data bana tha.
- Package id: com.ledgix.accounting (Play Store ke liye zaroori; com.example.* allowed nahi hai).
  Is id se pehle wala app alag app hai, purana data isme nahi aata.

Play Store par upload
---------------------
1. Play Console me new app banao. App name: Accounting of LEDGIX
2. Debug APK nahi, signed release AAB chahiye: Android Studio me
   Build > Generate Signed App Bundle / APK > Android App Bundle.
   Keystore file aur password safe rakho, wahi har update me lagega.
3. Har upload par versionCode (app/build.gradle.kts) badhana padta hai.
4. Play Console ki latest targetSdk requirement check karo (abhi targetSdk = 34).

Files
-----
- app/src/main/assets/ledgix.html   : poora app (UI + logic)
- app/src/main/java/...             : Kotlin (WebView, file picker, PDF share bridge)
- app/src/main/res/                 : icons, splash, colors

PDF upload (v5)
---------------
- New Bill screen me "PDF upload karke party & material bharo" button hai.
- PDF text-based hona chahiye (scanned image me text nahi milega).
- Pehli baar PDF reader (pdf.js) CDN se load hota hai, isliye internet chahiye.
- Party naam, GSTIN, phone, address aur items PDF se nikalte hain. Review screen me
  sab sahi karke "Form me bharo" dabao. Naye party/material apne aap save ho jate hain.
- Har PDF ka layout alag hota hai. Agar koi field galat aaye to review me sudhar lo.

Invoice / Challan designs (v7)
-----------------------------
- Invoice aur Challan dono me 18 designs hain: 10 purane + 8 naye.
- Naye 8 designs (reference layouts se prerna): Teal Wave, Navy Wave, Teal Diamond,
  Red Diamond, Blue Diagonal, Blue Mountain, Red Triangle, Blue Tag.
- Har naya design ka header/footer shape CSS se banta hai, koi image ya CDN zaroori nahi.
- Agar koi purana design (jaise pichle versions ka 'emerald') save tha to wo classic par wapas chala jata hai.

Party maal ka hisab (v6)
------------------------
- Menu / More me "Maal Hisab" tab hai. Party chuno, uska date-wise hisab dikhega.
- Columns material-wise: Diya (party ko diya) aur Wapas (party se wapas aaya).
- Sale bill ka maal apne aap "Diya" me judta hai, Purchase bill ka maal "Wapas" me.
- Manual entry: date, material, Diya/Wapas, qty, optional rate, note (jaise "14 MTR 25 = 350").
- Baaki = Diya - Wapas. Positive = party ke paas maal hai.
- Print / PDF button se party ka hisab print ya PDF me save ho jata hai.

PDF aur Print (v8)
------------------
- Invoice aur challan ka PDF ab hamesha ek hi A4 page par banta hai. Lambi bill ho to poora page proportionally chhota ho jata hai.
- Print me doc printable area (A4 minus 10 mm margin) me fit hota hai, right side nahi katta.
- Android print A4 aur 10 mm margin ke saath chalta hai.

Bill/Challan ki lambai aur pages (v9)
-------------------------------------
- Bill ki height items ke hisab se hoti hai. Kam items ki bill chhoti rehti hai, khali jagah nahi bharti.
- 10 items tak ek page. 11 se 20 items par 2 pages, 21 se 30 par 3, aur aage isi tarah.
- Har page par firm header, bill-to aur "Page x / n" aata hai.
- Total, GST, sign aur declaration sirf aakhri page par aate hain.
- PDF me har page ek alag A4 page banta hai. Print me bhi page break apne aap hota hai.

Page size (v10)
---------------
- Masters me "Page size" card hai: A4, Legal (8.5 x 14 in), Letter (8.5 x 11 in), A5.
- Chuni hui size par hi bill/challan ka PDF aur print banta hai. Print me margin 10 mm.
- Legal aur Letter A4 se thode chhote/lambe hain, isliye content apne aap scale hota hai aur ek page par fit rehta hai.
- Android print me bhi chuna hua size use hota hai.
