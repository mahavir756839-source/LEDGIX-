LEDGIX (Bajrang Tally) - Android Studio project

1. Android Studio me File > Open karo aur ye BajrangTally folder chuno.
2. Gradle sync hone do (pehli baar internet chahiye).
3. Build > Build Bundle(s) / APK(s) > Build APK(s) chuno.
4. Build hone par "locate" par click karo. APK ka path:
   app/build/outputs/apk/debug/app-debug.apk
5. Ye APK phone me bhejkar install karo.

Naya bajrang-tally.html badalna ho to:
app/src/main/assets/bajrang-tally.html ko replace karo, phir dobara Build APK karo.

--- Mobile / bina Android Studio ke ---
GitHub Actions se cloud par APK bana sakte ho:
1. GitHub par free account banao aur ek naya repository (private ya public) banao.
2. Is project ke sab files repository me upload karo (folder structure same rakhna).
3. Repository me "Actions" tab kholo, "Build APK" workflow chalega.
4. Workflow khatam hone par "LEDGIX-apk" artifact download karo, usme se LEDGIX-debug.apk nikaal kar install karo.
LEDGIX branding: App name LEDGIX. Invoice and delivery challan templates include a small Powered by LEDGIX footer. Firm name/logo are configurable in Firm Details. Five invoice and five challan style options are provided.

Invoice/challan template workflow:
- After saving a bill, the preview opens with per-bill Invoice template and Challan template selectors.
- Changing either selector immediately saves that choice to the bill record.
- The invoice preview and generated PDF use the selected invoice template; delivery challan preview/print uses the selected challan template.
- Each bill retains its own template selection, independent of the default templates in Firm Details.
